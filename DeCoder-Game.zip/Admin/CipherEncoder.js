let message = prompt("Enter a message to encode/decode:")
const cipherMap = {
      'a': '~',
      'b': '!',
      'c': '@',
      'd': '#',
      'e': '$',
      'f': '%',
      'g': '^',
      'h': '&',
      'i': '*',
      'j': '(',
      'k': ')',
      'l': '_',
      'm': '+',
      'n': '{',
      'o': '}',
      'p': '|',
      'q': ':',
      'r': '"',
      's': '<',
      't': '>',
      'u': '?',
      'v': '`',
      'w': '-',
      'x': '=',
      'y': '[',
      'z': ']',
      '~': 'a',
      '!': 'b',
      '@': 'c',
      '#': 'd',
      '$': 'e',
      '%': 'f',
      '^': 'g',
      '&': 'h',
      '*': 'i',
      '(': 'j',
      ')': 'k',
      '_': 'l',
      '+': 'm',
      '{': 'n',
      '}': 'o',
      '|': 'p',
      ':': 'q',
      '"': 'r',
      '<': 's',
      '>': 't',
      '?': 'u',
      '`': 'v',
      '-': 'w',
      '=': 'x',
      '[': 'y',
      ']': 'z'
    };
    function encode(message) {
      let encoded = '';
      for (let i = 0; i < message.length; i++) {
        const char = message[i].toLowerCase();
        if (cipherMap[char]) {
          encoded += cipherMap[char];
        } else {
          encoded += char;
        }
      }
      return encoded;
    }
    function decode(encodedMessage) {
      let decoded = '';
      for (let i = 0; i < encodedMessage.length; i++) {
        const char = encodedMessage[i];
        for (const key in cipherMap) {
          if (cipherMap[key] === char) {
            decoded += key;
            break;
          }
        }
        if (cipherMap[char] === undefined) {
          decoded += char; 
        }
      }
      return decoded;
    }

    const encoded = encode(message);
    const decodedMessage = decode(encoded);

    alert(`Original message: ${message.bold()}`);
    alert(`Encoded message: ${encoded}`);
    alert(`Decoded message: ${decodedMessage}`);